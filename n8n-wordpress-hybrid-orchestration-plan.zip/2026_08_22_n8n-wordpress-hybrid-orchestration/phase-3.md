---
status: pending
---

# Instruction: Idempotent MCP site construction

## Architecture projection

> Tree of the final files. ✅ create · ✏️ modify · ❌ delete

```txt
automation/
├── policies/
│   └── mcp-tool-policy.json                  ✅
└── workflows/
    └── 20-wordpress-builder.json             ✅
includes/
├── class-tool-registry.php                   ✏️
└── tools/
    └── class-posts-tool.php                  ✏️
```

## User Journey

```mermaid
flowchart TD
  A[Infrastructure completed] --> B[Builder receives scoped artifacts]
  B --> C[Generate ordered MCP tool calls]
  C --> D[Policy checks tool and arguments]
  D -->|Rejected| E[Return changes_requested]
  D -->|Accepted| F[Apply idempotent mutation on staging]
  F --> G[Read back WordPress object]
  G --> H{Matches expected artifact?}
  H -->|No| C
  H -->|Yes| I[Return build manifest and evidence]
```

## Test Scope

```mermaid
---
title: Test scope
---
journey
  section Setup
    Load completed infrastructure result and canonical site contract => staging identifiers are available: 5: api
  section Happy path
    Build pages content media and Elementor structures => manifest maps each artifact to one WordPress object: 5: api
    Replay builder workflow => existing objects are updated without duplication: 5: api
  section Edge case - Disallowed mutation
    Builder requests permanent deletion or production URL => policy blocks tool call and records finding: 1: api
  section Edge case - Interrupted build
    Execution stops after page creation => retry resumes using stored artifact IDs: 1: api
  section Teardown
    Archive staging fixture build => canonical test site remains isolated: 5: api
```

## Tasks to do

### `1)` Add idempotent page mutation support

> Ensure n8n retries cannot create duplicate WordPress content.

1. Extend the post tool contract with an upsert operation keyed by request ID and artifact key.
2. Store and retrieve the idempotency key using protected post metadata.
3. Return explicit MCP error results and stable WordPress IDs.
4. Enforce object-level create, publish, read, update, and delete capabilities.

### `2)` Define MCP policy

> Restrict the builder to approved staging mutations.

1. Allow only tools needed by the current phase and argument bounds defined by the canonical contract.
2. Deny permanent deletion, unverified uploads, production targets, and content containing unresolved placeholders marked as non-publishable.
3. Require read-back verification after each mutation group.

### `3)` Build the construction sub-workflow

> Turn approved architecture, content, and design artifacts into verified staging objects.

1. Pass only the current page or component slice to the builder agent.
2. Execute ordered MCP calls for pages, media, Elementor data, forms/SEO references, and navigation links.
3. Persist artifact-to-WordPress-ID mappings immediately after each successful call.
4. Produce a build manifest containing URLs, IDs, checksums, unresolved placeholders, and execution evidence.

## Test acceptance criteria

| Task | Acceptance criteria |
| ---- | ------------------- |
| 1 | Two executions with the same request and artifact keys result in one WordPress object per artifact. |
| 2 | Forbidden or unsafe MCP calls are blocked before mutation and appear in structured workflow evidence. |
| 3 | Every completed build manifest can be traced from contract artifact to WordPress ID and staging URL. |
