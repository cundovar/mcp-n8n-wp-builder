---
status: pending
---

# Instruction: Contract intake and state gates

## Architecture projection

> Tree of the final files. ✅ create · ✏️ modify · ❌ delete

```txt
automation/
├── contracts/
│   ├── site-build-request.schema.json       ✅
│   ├── agent-result.schema.json             ✅
│   └── review-result.schema.json            ✅
├── policies/
│   └── build-state-policy.json               ✅
└── workflows/
    └── 00-site-build-intake.json             ✅
```

## User Journey

```mermaid
flowchart TD
  A[Submit canonical site-build JSON] --> B[Validate schema and contract version]
  B --> C{Critical information missing?}
  C -->|Yes| D[Set needs_input and keep dry_run]
  D --> E[Request human completion]
  E --> B
  C -->|No| F[Human approves staging build]
  F --> G[Set ready_for_staging]
```

## Test Scope

```mermaid
---
title: Test scope
---
journey
  section Setup
    Load a valid contract fixture and an incomplete fixture => two isolated request IDs exist: 5: api
  section Happy path
    Submit complete contract => contract is stored as ready for human staging approval: 5: api
    Approve staging build => state becomes ready_for_staging with approver and timestamp: 5: api
  section Edge case - Incomplete contract
    Submit missing business coordinates => state becomes needs_input and no executor starts: 1: api
  section Edge case - Conflicting statuses
    Submit approved metadata with validated false => policy normalizes to dry_run and blocks execution: 1: api
  section Teardown
    Delete fixture records => build-state table returns to baseline: 5: api
```

## Tasks to do

### `1)` Define canonical contracts

> Make every workflow and agent exchange machine-validatable.

1. Define the request schema with contract version, request ID, stage artifacts, missing information, risks, and requested execution mode.
2. Define agent result and review result schemas with status, outputs, evidence, findings, retryability, and correlation fields.
3. Reject unknown contract versions and preserve the original payload checksum.

### `2)` Define build states and gates

> Remove ambiguous combinations such as approved plus validated false.

1. Use `received`, `needs_input`, `awaiting_staging_approval`, `ready_for_staging`, `building`, `reviewing`, `changes_requested`, `awaiting_publish_approval`, `publishing`, `completed`, and `failed`.
2. Require explicit transitions, actor, timestamp, and reason.
3. Force `dry_run` whenever critical information or high unmitigated risk remains.

### `3)` Build the intake workflow

> Receive, validate, store, and route one request safely.

1. Receive JSON through an authenticated webhook.
2. Validate schema, normalize conflicting statuses, and store the canonical payload plus execution state in an n8n Data Table.
3. Request missing information or staging approval through a human-review channel.
4. Start phase 2 only after a valid approval event tied to the request ID.

## Test acceptance criteria

| Task | Acceptance criteria |
| ---- | ------------------- |
| 1 | Invalid or unsupported contracts are rejected with field-level errors; valid contracts retain their checksum and request ID. |
| 2 | No transition can move an incomplete or unapproved request into `ready_for_staging`. |
| 3 | One approved complete request starts exactly one infrastructure sub-workflow; duplicates reuse the existing execution record. |
