---
objective: "A validated site-build contract can be executed repeatably on WordPress staging, independently reviewed, corrected, and published only after explicit human approval."
status: pending
---

# Plan: n8n WordPress hybrid orchestration

## Overview

| Field      | Value |
| ---------- | ----- |
| **Goal**   | Orchestrate WP-CLI infrastructure, MCP construction, independent QA, correction loops, and human-gated publication through n8n. |
| **Source** | User request plus `/home/cundo/.codex/attachments/64a7aa6e-fd9f-4e73-9300-98e1c4a3eeeb/pasted-text.txt` |

## Phases

| #   | Phase | File |
| --- | ----- | ---- |
| 1 | Contract intake and state gates | [`phase-1.md`](./phase-1.md) |
| 2 | Restricted WP-CLI infrastructure executor | [`phase-2.md`](./phase-2.md) |
| 3 | Idempotent MCP site construction | [`phase-3.md`](./phase-3.md) |
| 4 | Independent review, correction loop, and publication gate | [`phase-4.md`](./phase-4.md) |

## Resources

| Source | Verified |
| ------ | -------- |
| https://docs.n8n.io/ | n8n supports self-hosted workflow automation, AI tooling, webhooks, waits, data handling, and integrations. |
| https://docs.n8n.io/advanced-ai/human-in-the-loop-tools/ | Critical AI tool calls can pause for deterministic human review before execution. |
| https://github.com/n8n-io/n8n-docs/blob/main/docs/integrations/builtin/core-nodes/n8n-nodes-base.executeworkflow.md | Large workflows can be decomposed into callable sub-workflows with explicit inputs. |
| https://docs.n8n.io/workflows/executions/all-executions/ | Executions are traceable and failed runs can be retried with prior inputs. |

## Decisions

| Decision | Why |
| -------- | --- |
| The structured JSON is canonical; the text plan is generated for humans only. | Avoids two competing sources of truth and lets n8n validate fields deterministically. |
| n8n orchestrates three bounded agents rather than allowing a free multi-agent conversation. | Makes every transition observable, testable, and recoverable. |
| WP-CLI execution uses an allow-listed staging runner, never model-generated arbitrary shell. | Limits command-injection and production blast radius. |
| MCP mutations are idempotent and keyed by `request_id` plus artifact key. | Retries must not duplicate pages, menus, forms, or content. |
| Independent review is read-only and publication requires a human approval token. | The builder cannot approve itself or publish directly. |
| Version 1 stops at an abstract production adapter. | The hosting-specific staging-to-production mechanism is unknown and must remain replaceable. |
