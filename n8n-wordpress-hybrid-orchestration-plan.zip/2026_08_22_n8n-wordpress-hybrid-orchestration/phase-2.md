---
status: pending
---

# Instruction: Restricted WP-CLI infrastructure executor

## Architecture projection

> Tree of the final files. ✅ create · ✏️ modify · ❌ delete

```txt
automation/
├── policies/
│   └── wp-cli-allowlist.json                 ✅
├── runners/
│   ├── wp-cli-build-runner.sh                ✅
│   └── wp-cli-health-check.sh                ✅
└── workflows/
    └── 10-wordpress-infrastructure.json      ✅
```

## User Journey

```mermaid
flowchart TD
  A[Receive ready_for_staging request] --> B[Infrastructure agent proposes normalized actions]
  B --> C[Policy validates allow-listed actions]
  C -->|Rejected| D[Record blocked action and stop]
  C -->|Accepted| E[Runner applies WP-CLI actions on staging]
  E --> F[Health check WordPress]
  F -->|Pass| G[Return infrastructure result JSON]
  F -->|Fail| H[Return retryable or terminal failure]
```

## Test Scope

```mermaid
---
title: Test scope
---
journey
  section Setup
    Provision disposable WordPress staging fixture => site is reachable with baseline snapshot: 5: cli
  section Happy path
    Apply approved theme plugin and settings actions => expected stack is active and health check passes: 5: cli
    Reapply same request => no duplicate resource or unintended change occurs: 5: cli
  section Edge case - Forbidden command
    Agent proposes arbitrary shell command => policy rejects action before SSH execution: 1: cli
  section Edge case - Partial failure
    Plugin activation fails => result identifies failed action and safe retry point: 1: cli
  section Teardown
    Restore disposable staging snapshot => baseline WordPress state is restored: 5: cli
```

## Tasks to do

### `1)` Define the infrastructure action allow-list

> Convert the WordPress plan into bounded operations rather than arbitrary commands.

1. Allow only known theme/plugin installation, activation, option updates, permalink flushes, menu operations, and health checks.
2. Deny shell metacharacters, arbitrary paths, unknown plugin sources, production hosts, and destructive database/filesystem operations.
3. Bind every execution to staging credentials and the request ID.

### `2)` Implement the staging runner

> Execute validated WP-CLI actions with observable results.

1. Accept a normalized action file, not free-form shell text.
2. Emit one structured result per action with before state, after state, exit status, duration, and redacted diagnostics.
3. Make installation, activation, settings, theme-child, menu, form, and SEO setup operations safe to retry.

### `3)` Build the infrastructure sub-workflow

> Coordinate the infrastructure agent, policy gate, runner, and recovery behavior.

1. Pass only `wordpress`, relevant `design`, and environment policy slices to the agent.
2. Validate the proposal before invoking the runner over SSH.
3. Retry transient failures with a cap; route policy violations and terminal failures to human review.
4. Store produced IDs, versions, URLs, and configuration evidence for phase 3.

## Test acceptance criteria

| Task | Acceptance criteria |
| ---- | ------------------- |
| 1 | An action outside the explicit allow-list cannot reach the SSH runner or production environment. |
| 2 | A complete approved infrastructure plan produces the required WordPress stack and returns verifiable structured evidence. |
| 3 | Replaying a successful request is idempotent, while partial failures resume from a known safe action. |
