---
status: pending
---

# Instruction: Independent review, correction loop, and publication gate

## Architecture projection

> Tree of the final files. ✅ create · ✏️ modify · ❌ delete

```txt
automation/
├── policies/
│   ├── review-policy.json                    ✅
│   └── publication-policy.json               ✅
├── workflows/
│   ├── 30-wordpress-review.json              ✅
│   ├── 35-wordpress-correction-loop.json     ✅
│   └── 40-wordpress-publish.json             ✅
└── README.md                                  ✅
```

## User Journey

```mermaid
flowchart TD
  A[Build manifest completed] --> B[Read-only reviewer inspects contract and staging]
  B --> C{Blocking findings?}
  C -->|Yes| D[Return structured changes request]
  D --> E[Builder corrects only rejected artifacts]
  E --> B
  C -->|No| F[Await human publication approval]
  F -->|Rejected| D
  F -->|Approved| G[Invoke production adapter]
  G --> H[Run post-publication smoke checks]
  H -->|Fail| I[Stop expose alert and execute configured recovery]
  H -->|Pass| J[Mark completed]
```

## Test Scope

```mermaid
---
title: Test scope
---
journey
  section Setup
    Provide a passing staging build and a build with known defects => reviewer has two isolated URLs: 5: browser
  section Happy path
    Review compliant staging build => signed review result requests human publication approval: 5: browser
    Approve matching build checksum => production adapter runs and smoke checks pass: 5: browser
  section Edge case - Review failure
    Detect broken form or unresolved placeholder => only affected artifacts return to builder: 1: browser
  section Edge case - Stale approval
    Approve older build checksum => publication is rejected without production action: 1: browser
  section Edge case - Publication failure
    Post-publish smoke check fails => workflow stops alerts and runs configured recovery policy: 1: browser
  section Teardown
    Revoke fixture approvals and archive execution evidence => test approvals cannot be reused: 5: system
```

## Tasks to do

### `1)` Define independent review policy

> Make review evidence-based and prohibit self-approval.

1. Give the reviewer read-only browser, WordPress read, and contract access with no mutation credentials.
2. Check required pages, responsive layouts, navigation, forms, accessibility basics, SEO fields, performance budgets, placeholders, and contract conformance.
3. Return `approve` or `changes_requested` with severity, artifact key, evidence, and expected correction.

### `2)` Build the bounded correction loop

> Correct defects without rebuilding accepted work indefinitely.

1. Send only rejected artifact slices and findings back to the builder.
2. Cap automatic correction attempts and escalate repeated or critical failures to a human.
3. Generate a new build checksum after each correction and invalidate earlier approvals.

### `3)` Build publication and recovery gates

> Ensure only the exact reviewed build can reach production.

1. Require explicit human approval containing request ID, build checksum, target environment, approver, and expiry.
2. Invoke a hosting-specific production adapter without exposing production credentials to agents.
3. Run post-publication checks for availability, page count, navigation, form submission path, indexing state, and critical visual regressions.
4. Record completion evidence or execute the configured recovery action and alert maintainers.

### `4)` Document operation

> Make the workflow understandable and recoverable by its owner.

1. Document credentials, environment bindings, state transitions, retries, approval channels, timeouts, and manual recovery.
2. Document how to replace the production adapter for the chosen hosting provider.
3. Document which evidence is retained and which customer data must be redacted or expired.

## Test acceptance criteria

| Task | Acceptance criteria |
| ---- | ------------------- |
| 1 | The reviewer can prove conformance or report artifact-specific defects but cannot mutate WordPress. |
| 2 | Failed reviews trigger bounded targeted corrections; repeated failures stop for human intervention. |
| 3 | Production rejects missing, expired, mismatched, or stale approvals and accepts only the latest reviewed checksum. |
| 4 | An operator can trace, retry, stop, and recover a build using the documented execution and state records. |
